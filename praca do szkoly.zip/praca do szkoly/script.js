let kolor = document.getElementById("zmianaMotywu");
let naglowek = document.getElementById("naglowek");
let produkty = document.getElementById("productSektor");
let stopka = document.getElementById("stopka");

function zmienKolorBody(kolor) {
    document.getElementById("body").style.background = kolor;
}

function zmienKolorProdukt(kolor) {
    document.getElementById("productSektor").style.background = kolor;
}

function zmienKolorNaglowek(kolor) {
    document.getElementById("naglowek").style.background = kolor;
}

function zmienKolorStopka(kolor) {
    document.getElementById("stopka").style.background = kolor;
}

function zmianaMotywu() {
    zmienKolorBody('white');
    zmienKolorProdukt('lightgray');
    zmienKolorNaglowek('gray');
    zmienKolorStopka('gray');
}

