<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>G4G sklep z częściami komputerowymi</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header id="naglowek">
        <h1>G4G sklep z częściami komputerowymi</h1>
        <a href="index.html"><img id="logo" src="images/logo.png" alt="LOGO"></a>

        <button id="ZmianaMotywu" onclick="zmianaMotywu()">ZMIEŃ MOTYW</button>

        <a href="login.html" target="_blank" id="kontoPrzycisk">KONTO</a>
        <a href="stronaKoszyk.php" target="_blank" id="koszykPrzycisk">KOSZYK</a>

    </header>

<main>
    <section>
        <h2>Twój koszyk</h2>
        <p>Twój koszyk jest pusty</p>
    </section>
</main>

<footer>
    <div class="footer-content">
        <p>Telefon: 000-000-000</p>
        <p>Email: sklepzczesciami@email.com</p>
        <p>Autor: Adam Blank 3E</p>
        <a href="stronaFAQ.html" class="faq-link">FAQ</a>
    </div>
</footer>

</body>
</html>
