<?php
    $host = "localhost";
    $user = "root";  
    $pass = "" ;   
    $dbname = "userdata"; 

    $conn = new mysqli($host,$user,$pass,$dbname); 

    if ($conn -> connect_error)
    {
        die("Błąd połacznia: " . $conn->connect_error); 
    }

    if($_SERVER["REQUEST_METHOD"]=="POST")
    {
        $login = $_POST["login"];
        $password = $_POST["password"];
    }

        $sql = "INSERT INTO userdata (login, password) VALUES ('$login', '$password')" ; 
        if($conn->query($sql) === TRUE){
        echo "Zostałeś poprawnie zarejestrowany"; 
        header("Refresh: 3; url=login.html");}
        } else{
        echo "Błąd" . $conn->error ;
        }

     $conn -> close(); 
    ?>