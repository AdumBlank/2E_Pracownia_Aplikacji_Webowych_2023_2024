<?php
    $host = "localhost";
    $user = "root";  
    $pass = ""; 
    $dbname = "userdata"; 

    $conn = new mysqli($host , $user , $pass , $dbname); 
    if ($conn -> connect_error)
    {
        die("Błąd połacznia: " . $conn->connect_error); 
    }

    if($_SERVER["REQUEST_METHOD"]=="POST")
    {
        $login = $_POST["login"];
        $password = $_POST["password"];
    }

    $sql = "SELECT * FROM `userdata` WHERE login = '$login';";
    $result = $conn -> query($sql);
    if($result -> num_rows <= 0 )
    {
        echo "Nie poprawne dane"; 
    }
         $row = $result->fetch_assoc();
         
         if($row["password"] == $password){
             echo"Udało sie zalogować";
             echo"Zostaniesz przeniesiony na stronę konta";
             header("Refresh: 3; url=stronaKonto.php");}
         else{
             echo"Nie poprawne dane";
             header("Refresh: 3; url=login.html");}
    
    $conn -> close(); 
    ?>
    