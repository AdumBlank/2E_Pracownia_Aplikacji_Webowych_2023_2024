<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konto Użytkownika</title>
    <link rel="stylesheet" href="style.css">
    <script src="script.js"></script> 
</head>
<body>
<header id="naglowek">
        <h1>G4G sklep z częściami komputerowymi</h1>
        <a href="index.html"><img id="logo" src="logo.png" alt="LOGO"></a>

        <a href="stronaKoszyk.php" target="_blank" id="koszykPrzycisk">KOSZYK</a>

    </header>
    <main>
zalogowano

    </main>
    <footer id="stopka">
<p>Tel: 000-000-000</p>
<p>E-mail: sklepzczesciami@email.com</p>
<p>Adam Blank 3E</p>
<a href="stronaFAQ.html">F&Q</a>
</footer>
</body>
</html>